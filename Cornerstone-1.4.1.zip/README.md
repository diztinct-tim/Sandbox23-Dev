// ADD THIS TO YOUR CONFIG.JSON FILE NEAR OTHER IMAGE SIZES
"custom_gallery_size": "500x500",

"gallery_size": "300x300",
"productgallery_size": "500x659",
"product_size": "500x659",
"productthumb_size": "100x100",
"thumb_size": "100x100",
"zoom_size": "1280x1280",

